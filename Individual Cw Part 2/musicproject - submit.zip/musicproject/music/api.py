from django.http import JsonResponse
from django.http.response import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404

# View function that returns the artist data.
# {} pass the list of artists.

# Here we import the dictionary that is located in the models.py
# This is so we can pass it to one of the api methods.
from .models import Artist, Track
import json
# Send just 1 track.
def track_api(request, track_id):
    '''
        API entry point for each track.

    '''
    track = get_object_or_404(Track, id=track_id)
    if request.method == "DELETE":
        track.delete()
        return JsonResponse({})
    # PUT
    # Here we pass our PUT request
    if request.method == "PUT":
        PUT = json.loads(request.body)
        track.track_number = PUT['track_number']
        track.track_title = PUT['track_title']
        track.track_duration = PUT['track_duration']
        track.track_year = PUT['track_year']
        track.save()
        return JsonResponse({})
    return HttpResponseBadRequest("Invalid method.")
# Send the whole set of tracks.
def tracks_api(request):
    '''
        API entry point for list of tracks
        We can also use the GET, POST, PUT & DELETE method here.
    '''
    if request.method == "POST":
        POST = json.loads(request.body)
        track_number = POST['track_number']
        track_title = POST['track_title']
        track_duration = POST['track_duration']
        track_year = POST['track_year']
        
        track = Track.objects.create(
            track_number = track_number,
            track_title = track_title,
            track_duration = track_duration,
            track_year = track_year
        )
        track.save()
        return JsonResponse({})

    return JsonResponse({
        'track_list': [
            track.to_dict()
            for track in Track.objects.all()

        ]
    })

# Send just 1 artist.
def artist_api(request, artist_id):
    '''
        API entry point for each artist.

    '''
    if request.method == "DELETE":
        artist = get_object_or_404(Artist, id=artist_id)
        artist.delete()
        return JsonResponse({})
    return HttpResponseBadRequest("Invalid method.")
# Send the whole set of artist.
def artists_api(request):
    '''
        API entry point for list of artists
        We can also use the GET, POST, PUT & DELETE method here.
    '''
    return JsonResponse({
        'artist_list': [
            artist.to_dict()
            for artist in Artist.objects.all()
        ]
    })
