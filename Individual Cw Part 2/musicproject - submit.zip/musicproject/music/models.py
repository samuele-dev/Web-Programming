from django.db import models
from django.db.models.base import Model
from django.urls.base import reverse
# A Track can be in MANY albums and can have MANY Artists
# E.g.: Shawn Mendes & Camila Cabello -- "Señorita",
# Album: Romance, NOW That’s What I Call Music! 72
class Artist(models.Model):
    artist_name = models.CharField(max_length=100)
    artist_dob = models.DateField()
    artist_num_tracks = models.IntegerField(null=True)
    # Artist rating
    # Allows us to see the object representation.
    def __str__(self):
        return self.artist_name
    def to_dict(self):
        return {
            'id': self.id,
            'artist_name': self.artist_name,
            'artist_dob': self.artist_dob,
            'artist_num_tracks': self.artist_num_tracks,
            # This is important if you want to delete a specific row.
            'api': reverse('artist api', kwargs={'artist_id': self.id}),
        }

#class Album(models.Model):
    #album_title = models.CharField(max_length=100)
    # album_cover = models.ImageField() # default='default.png', blank=True
    #album_year = models.DateField()
    #album_genre = models.CharField(max_length=30)
    #album_rating = models.IntegerField()
    #def __str__(self):
        #return self.album_title

class Track(models.Model):
    track_number = models.IntegerField()
    track_title = models.CharField(max_length=100)
    track_duration = models.FloatField()
    track_year = models.DateField() 
    # Many to Many Fields:
    artists = models.ManyToManyField(Artist)
    #albums = models.ManyToManyField(Album)
    def __str__(self):
        return self.track_title
    # Turn an object into a dictionary.
    def to_dict(self):
        return {
            'id': self.id,
            #'artists': self.artists[1],
            'track_number': self.track_number,
            'track_title': self.track_title,
            'track_duration': self.track_duration,
            'track_year': self.track_year,
            # This is important if you want to delete a specific row.
            'api': reverse('track api', kwargs={'track_id': self.id}),
        }