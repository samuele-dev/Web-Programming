from django.urls import path
from . import views

from music.api import artists_api, artist_api
from music.api import tracks_api, track_api

urlpatterns = [
    # Track url
    path('track', views.track_view, name='track'),
    # Artist url
    path('artist', views.artist_view, name='artist'),
    # Album url
    #path('album', views.album_view, name='album'),
    
    # API for artists
    path('api/artists', artists_api, name='artists api'),
    # DELETE API for artist
    path('api/artist/<int:artist_id>/', artist_api, name='artist api'),
    # API for tracks
    path('api/tracks', tracks_api, name='tracks api'),
    # DELETE API for track
    path('api/track/<int:track_id>/', track_api, name='track api'),
]