from django.shortcuts import render
from .models import Artist, Track

# Retrieve all Track objects and send them to the track.html page.
def track_view(request):    
    track_list = Track.objects.all()
    context = {'track_list': track_list}
    return render(request, 'music/track.html', context)
# Retrieve all Artist objects and send them to the artist.html page.
def artist_view(request):
    artist_list = Artist.objects.all()
    context = {'artist_list': artist_list}
    return render(request, 'music/artist.html', context)
# Retrieve all Album objects and send them to the album.html page.
#def album_view(request):
#    album_list = Album.objects.all()
#    context = {'album_list': album_list}
#    return render(request, 'music/album.html', context)